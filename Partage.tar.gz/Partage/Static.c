#include <stdlib.h>
#include <stdio.h>
#include <ncurses.h>
#include <time.h>
#include <string.h>
#include <unistd.h>


int main()
{	
	
	FILE* stat=NULL;
	FILE* mem = NULL;
	FILE* image = NULL;
	FILE* histo = NULL;
	
	stat= fopen("historique/HStatic.txt","r");
	int stati;	
	fscanf(stat,"%d", &stati);
	stati++;	
	fclose(stat);
	stat = fopen("historique/HStatic.txt", "w");
	fprintf(stat,"%d", stati);
	fclose(stat);
	time_t t;
	t = time(NULL);
	
	

	int truc = 0;
	int centrex = 0;
	int centrey = 0;
	int i=0;
	int ale;
	int tabx = 0;
	int taby = 0;
	int x;
	int y;
	int voiture = 0;
	int paysage = 0;
	int chateau = 0;
	int fusee = 0;
	int chat = 0;
	char a = 0;
	char nom [255] = "";

	initscr();
	getmaxyx(stdscr, y, x);
	endwin();


	
	srand(time(NULL));
	ale = rand()%5;
	// ouvre histo, ajoute 1 dans les stats et chatge la bonne image
	if (ale == 0)
	{
	

		image = fopen("statique/voiture.pbm","r");		
		histo = fopen("historique/Hvoiture.txt","r");
		fseek(histo, 0, SEEK_SET);
		fscanf(histo, "%d", &voiture);
		fclose(histo);

		histo = fopen("historique/Hvoiture.txt","w");
		fseek(histo, 0, SEEK_SET);
		voiture++;
		fprintf(histo, "%d", voiture);
		fclose(histo);
	}	
	else if (ale == 1)
	{

		image = fopen("statique/paysage.pbm","r");
		histo = fopen("historique/Hpaysage.txt","r");
		fseek(histo, 0, SEEK_SET);
		fscanf(histo, "%d", &paysage);
		fclose(histo);

		histo = fopen("historique/Hpaysage.txt","w");
		fseek(histo, 0, SEEK_SET);
		paysage++;
		fprintf(histo, "%d", paysage);
		fclose(histo);
	}
	else if (ale == 2)
	{
		image = fopen("statique/Chateau.pbm","r");
		histo = fopen("historique/Hchateau.txt","r");
		fseek(histo, 0, SEEK_SET);
		fscanf(histo, "%d", &chateau);
		fclose(histo);

		histo = fopen("historique/Hchateau.txt","w");
		fseek(histo, 0, SEEK_SET);
		chateau++;
		fprintf(histo, "%d", chateau);
		fclose(histo);
	}
	else if (ale == 3)
	{
		
		image = fopen("statique/fusee.pbm","r");
		histo = fopen("historique/Hfusee.txt","r");
		fseek(histo, 0, SEEK_SET);
		fscanf(histo, "%d", &fusee);
		fclose(histo);

		histo = fopen("historique/Hfusee.txt","w");
		fseek(histo, 0, SEEK_SET);
		fusee++;
		fprintf(histo, "%d", fusee);
		fclose(histo);
	}
	else if (ale == 4)
	{
		

		image = fopen("statique/chat.pbm","r");
		histo = fopen("historique/Hchat.txt","r");
		fseek(histo, 0, SEEK_SET);
		fscanf(histo, "%d", &chat);
		fclose(histo);

		histo = fopen("historique/Hchat.txt","w");
		fseek(histo, 0, SEEK_SET);
		chat++;
		fprintf(histo, "%d", chat);
		fclose(histo);
	}

	fseek(image, 4, SEEK_SET);
	fgets(nom, 255, image);
	printf("%s\n", nom);				//centre l'image
	fscanf(image, "%d %d", &tabx, &taby);

	int result = tabx*taby;
	centrex = (x/2) - (tabx/2);
	centrey = (y/2) - (taby/2);
	

	for(truc = 0; truc < y; truc++)
		printf("\n");

	while (i != result){
    a = fgetc(image);
    usleep(100);
    if (a == 48)
        printf(" ");
    else if (a == 49)
        {
        printf("%c", 219);
         
        i--;
        }					//dessine l'image
    else if (a == 10)
        {
        printf("\n");
        for (truc = 0; truc < centrex; truc++)
            printf(" "); 
        }
    else if (a == 32)
        i--;
i++;
}

for(truc = 1; truc < centrey; truc++){
    usleep(10000);
    printf("\n");
    }

system("stty cbreak -echo");
getchar();				//attend une touche
system("stty cooked echo");

return 0;
}
