#include <stdlib.h>
#include <stdio.h>


int main()
{

	FILE* histo = NULL;

	float NbVoiture;			// valeur (nombre decimaux)
	float NbPaysage;
	float NbChateau;
	float NbFusee;
	float NbChat;
	
	float repVoiture;
	float repPaysage;
	float repChateau;
	float repFusee;
	float repChat;



		histo = fopen("historique/Hpaysage.txt","r");	// ouvre fichier txt
			fseek(histo, 0, SEEK_SET);		// ce place en debut de ligne dans le program
			fscanf(histo, "%f", &NbPaysage);	// prend la valeur inscrite dans le fichier
			fclose(histo);				// on ferme le fichier txt

		histo = fopen("historique/Hchat.txt","r");
			fseek(histo, 0, SEEK_SET);
			fscanf(histo, "%f", &NbChat);
			fclose(histo);
			
		histo = fopen("historique/Hfusee.txt","r");
			fseek(histo, 0, SEEK_SET);
			fscanf(histo, "%f", &NbFusee);
			fclose(histo);
					
		histo = fopen("historique/Hchateau.txt","r");
			fseek(histo, 0, SEEK_SET);
			fscanf(histo, "%f", &NbChateau);
			fclose(histo);
		
		histo = fopen("historique/Hvoiture.txt","r");
			fseek(histo, 0, SEEK_SET);
			fscanf(histo, "%f", &NbVoiture);
			fclose(histo);


	 repVoiture= (NbVoiture)/(NbVoiture + NbPaysage + NbChat + NbChateau + NbFusee)*100;	// on calcule
	 repChat   = (NbChat)/(NbPaysage + NbChat + NbVoiture + NbChateau + NbFusee)*100;	// le pourcentag
	 repChateau= (NbChateau)/(NbPaysage + NbChat + NbChateau + NbVoiture + NbFusee)*100;	// d'apparition
	 repFusee  = (NbFusee)/(NbPaysage + NbChat + NbChateau + NbFusee +  NbVoiture)*100;	// de chaque 
	 repPaysage= (NbPaysage)/(NbVoiture + NbChat + NbChateau + NbFusee + NbPaysage)*100;	//ecran
	
	system("clear");
		printf("Pourcentage de voiture : %f%%\nPourcentage de chat : %f%%\nPourcentage de chateau : %f%% \nPourcentage de fusee : %f%% \nPourcentage de paysage : %f%% \n",repVoiture, repChat, repChateau, repFusee, repPaysage);
printf("\nAppuyez sur une touche quelconque pour revenir au menu");
	
system("stty cbreak -echo");	// passe la commande en mode row	
getchar();	// prend un caractère
system("stty cooked echo");  // repasse la commande en mode cook
system("clear");
system("gcc menu.c -lncurses");	// il compile a nouveau le menu 
system("./a.out");		// pour ensuite l'ouvrir
}





	
		
	
