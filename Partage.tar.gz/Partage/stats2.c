#include <stdlib.h>
#include <stdio.h>


int main()
{

FILE* histo = NULL;

	float NbStatic;
	float NbHorloge;
	float NbAvion;
	float repStatic;
	float repHorloge;
	float repAvion;	
	
	
	histo = fopen("historique/HStatic.txt","r");		//ouvre le fichier
			fseek(histo, 0, SEEK_SET);		// ce place au debut
			fscanf(histo, "%f", &NbStatic);		// prend la valeur inscrite dans le fichier
			fclose(histo);				// ferme le fichier

	histo = fopen("historique/HHorloge.txt","r");
			fseek(histo, 0, SEEK_SET);
			fscanf(histo, "%f", &NbHorloge);
			fclose(histo);

	histo = fopen("historique/HAvion.txt","r");
			fseek(histo, 0, SEEK_SET);
			fscanf(histo, "%f", &NbAvion);
			fclose(histo);

	repStatic= (NbStatic)/(NbStatic + NbHorloge + NbAvion)*100;	// calcul le pourcentage, de l'apparition
	repHorloge = (NbHorloge)/(NbStatic + NbHorloge + NbAvion)*100; // de chaque type d'ecran
	repAvion= (NbAvion)/(NbStatic + NbHorloge + NbAvion)*100;




		system("clear");
		printf("Frequence pour le mode vieille statique : %f%%\nFrequence pour l'horloge : %f%%\nFrequence pour l'avion : %f%% \n\n",repStatic, repHorloge, repAvion);
printf("Appuyez sur une touche quelconque pour revenir au menu");

system("stty cbreak -echo"); // passe la commande en mode row
getchar();
system("stty cooked echo"); // repasse la commande en mode cook
system("clear");
system("gcc menu.c -lncurses");	// il compile a nouveau le menu 
system("./a.out");		// pour ensuite l'ouvrir
}


