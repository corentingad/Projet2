#include <stdio.h>
#include <stdlib.h>

int affichageMenu(void)
{
	char choixMenu;
	
system("clear");

 
	printf("======Menu=====\n\n");
	printf("Quelles statistiques souhaitez-vous afficher : \n\n");
	printf("1.Statistiques concernant le mode statique\n");
	printf("\n");
	printf("2.Statistiques concernant tout les modes de veilles possibles\n");		//affiche le menu
	printf("\n");
	printf(">>> Faites b puis entree pour revenir en arriere <<<\n");
	printf("\n");

	scanf("%c", &choixMenu);
	return choixMenu;
}
int main(void)
{
	switch (affichageMenu())
	{
	case 49:

		system("gcc stats.c ");			//compile et execute le bon programme
		system("./a.out");
		break;
	case 50:
		system("gcc stats2.c");
		system("./a.out");
		
		break;
	case 98:
		system("clear");
		break;
	
	default:
		printf("Vous n avez choisis aucun des choix mis a votre disposition\n");

		break;
	}

	getchar();
	return 0;
}
