
#include <stdlib.h>
#include <stdio.h>
#include <time.h>	

int main(void)
{

	FILE* fichier = NULL;
	int i = 0;
	int random = 0;

	srand(time(NULL));	// Initialisation de rand
		random = rand()%3;

	if (random == 0)	// si le random = 0 alors, 
	{	
		system("/home/coco/projet2/Partage/static");	// on ouvre le fond d ecran statique
	}
	else if (random == 1)	// si il est egal a 1
	{
		system("/home/coco/projet2/Partage/horloge");	// alors on ouvre le fond d ecran dynamique
	}
	else if (random == 2)	// et si il est egal a 2
	{
		system("/home/coco/projet2/Partage/avion"); // alors on ouvre le fond d ecran interactif
	}

	return 0;
}
