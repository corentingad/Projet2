#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>	// pour usleep, seek
#include <sys/ioctl.h>	// pour la taille de la fenêtre


FILE* avion = NULL;


void histo()	// fonction qui gère les stats
{
	FILE* stat = NULL;
	stat = fopen("historique/HAvion.txt","r");		//1er partie permet de d'ouvrir et de lire
	int stati;					       //le fichier HAvion.txt et ajoute 1 à la 
	fscanf(stat, "%d", &stati);			       // nouvelle valeur
	stati++;
	fclose(stat);

	stat = fopen("historique/HAvion.txt","w");		// réecrit la nouvelle valeur
	fprintf(stat,"%d",stati);
	fclose(stat);
}


int placement_curs()			// place le curseur au bonne endroit dans la fonction choidraw
{					// permet de calculer les dimensions pour pouvoir compter le nbr de pix
	int tabx;	
	int taby;
	char nom[255];

	fseek(avion, 4, SEEK_SET);
		fgets(nom, 255, avion);
		fscanf(avion, "%d %d", &tabx, &taby);
		fgetc(avion);
		fgetc(avion);

	return tabx*taby;

}


void placement(int coorx, int coory)		// place l'avion en ajoutant des espaces et des à la ligne en
{
	int nbr;				// en fonction des coordonnées de l'avion

	for (nbr = 0; nbr < coory; nbr++)
		printf("\n");

	for (nbr = 0 ; nbr < coorx; nbr ++)
		printf (" ");
}


void choidraw(int i, int j)		// selectionne le bon dessin d'avion
{	
	
	if (i == 1)
		avion = fopen("Avions/droite.pbm","r");

	if (i == -1)
		avion = fopen("Avions/gauche.pbm","r");
								//Ouvre le bon fichier 
	if (j == 1)
		avion = fopen("Avions/bas.pbm","r");

	if (j == -1)
		avion = fopen("Avions/haut.pbm","r");
}


void avion_draw(int rep, int coorx)
{
	int nbr = 0;	
	int b = 0;
	char a = 0;

	while (b != rep){
		a = fgetc(avion);
		if (a == 48)
			printf(" ");
		else if (a == 49)
			{
			printf("%c", 219);
			b--;			//Affiche le pbm ligne par ligne 
			}
		else if (a == 10)
			{
			printf("\n");
			for (nbr = 0; nbr < coorx; nbr++)
				printf(" "); 
			}
		else if (a == 32)
			b--;
		b++;
	}
}


void replissage(int coory, int y)
{
	int nbr;
	for (nbr = coory; nbr < y; nbr++) //Affiche l'image au bonne coor Y
		printf("\n");
	fflush(stdout);			//force le refresh
}


int unix_text_kbhit(void)			// detecte la pression des touches
{ 
    struct timeval tv = { 0, 0 }; 
    fd_set readfds; 
  
    FD_ZERO(&readfds); 
    FD_SET(STDIN_FILENO, &readfds); 
  
    return select(STDIN_FILENO + 1, &readfds, NULL, NULL, &tv) == 1; 
}


void det_act(int* vi, int* vj, int* pa)		// detecte la touche sur laquelle ta appuyer
{
	if (unix_text_kbhit()){
		system("stty cbreak -echo");
		*pa = getchar();
		system("stty cooked echo");
	}

	if (*pa == 122){			
		*vi = 0;		//modifie la valeur des vecteurs directionnels 
		*vj = -1;
	}
	if (*pa == 115){
		*vi = 0;
		*vj = 1;
	}
	if (*pa == 113){
		*vi = -1;
		*vj = 0;
	}
	if (*pa == 100){
		*vi = 1;
		*vj = 0;
	}
}


int main(){
	
	char nom[255];
	int a;
	int* pa;	

	int b;
	int x;
	int y; 
	int coory=10;
	int coorx=20;
	int truc = 0;
	int rep;

	int i = 0;
	int j = -1;
	int* pi = &i;
	int* pj = &j;
		
	histo();

	struct winsize w;				// Ça prend la taille de l'écran
    	ioctl(0, TIOCGWINSZ, &w);
		
	y = w.ws_row;
	x = w.ws_col;

while (*pa != 98){				// tant que a est différent de 98 (b), la boucle continue.

	coorx = coorx + i;			// chaque sigle de boucle ça fait avancer l'avion en fonction 
	coory = coory + j;			// de i et j

	choidraw(i,j);				// selectionne le bon desssin d avion

	placement(coorx,coory);			// voir la fonction du placement de l'avion

	rep = placement_curs();			// donne a rep : le nbr de fois que la fonction aviondraw
						// doit boucler pour afficher en entier l'avion
	avion_draw(rep,coorx); 		// afficher l'avion

	replissage(coory,y);		// rempli le reste

	det_act (pi,pj,pa);		// detection de touche

	if (x == coorx)			// quand l'avion change de cote
		coorx = 1;
	if (coorx == 0)
		coorx = (x-1);
	if (y == coory)
		coory = 1;
	if (coory == 0) 
		coory = y;

	usleep(50000);			// pour faire des petites pauses
	}
}
