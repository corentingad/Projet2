#include <stdlib.h>
#include <stdio.h>
#include <ncurses.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>


int main()
{	
	FILE* deuxpt2 = NULL;	
	FILE* deuxpt = NULL;	
	FILE* mem = NULL;	
	FILE* un = NULL;
	FILE* deux = NULL;
	FILE* trois = NULL;		//initialise tous les pointeurs des fichiers
	FILE* quatre = NULL;
	FILE* cinq = NULL;
	FILE* six = NULL;
	
	int truc = 0; 
	char nom[255];
	int centrex = 0;
	int centrey = 0;
	int i = 0;
	int tabx = 0;
	int taby = 0;
	int x;
	int y;
	int a = 0;
	int tmp;
	
	FILE* config = NULL;
	config = fopen("/home/coco/projet2/Partage/Horloge/config.txt","r");
	int configu;	
	fscanf(config, "%d", &configu);
	fgets(nom, 255, config);
		fscanf(config, "%d", &tmp);
	fclose(config);
	
	FILE* stat = NULL;
	stat = fopen("/home/coco/projet2/Partage/historique/HHorloge.txt","r");		//1er partie permet de d'ouvrir et de lire
	int stati;					       //le fichier HHorloge.txt et ajoute 1 à la 
	fscanf(stat, "%d", &stati);			       // nouvelle valeur
	stati++;
	fclose(stat);

	stat = fopen("/home/coco/projet2/Partage/historique/HHorloge.txt","w");		// réecrit la nouvelle valeur
	fprintf(stat,"%d",stati);
	fclose(stat);
		

	while(1)
	{
			time_t secondes;
		    	struct tm instant;
		 
		   	time(&secondes);
		   	instant=*localtime(&secondes);
	
			struct winsize w;
		    	ioctl(0, TIOCGWINSZ, &w);
			y = w.ws_row;
			x = w.ws_col;

			mem = fopen("/home/coco/projet2/Partage/Horloge/clock.txt","w");
			fseek(mem, 0, SEEK_SET);
			fprintf(mem, "%02d%02d%02d", instant.tm_hour, instant.tm_min, instant.tm_sec);
			fclose(mem);

			mem = fopen("/home/coco/projet2/Partage/Horloge/clock.txt","r");
			a = fgetc(mem);
			fseek(mem, 0, SEEK_SET);
	
			centrex = (x/2) - (15);
			centrey = (y/2) - (3);
	
			for (truc = 0 ; truc < centrey ; truc++)
			printf("\n");

			a = fgetc(mem);

		// Ouvre les fichier dans chaque nombre a afficher (un peu crade)
		switch (a)
		{
			case 48:
			  un = fopen("/home/coco/projet2/Partage/Horloge/0.pbm","r");
			  break;
			case 49:
			  un = fopen("/home/coco/projet2/Partage/Horloge/1.pbm","r");
			  break;
			case 50:
			  un = fopen("/home/coco/projet2/Partage/Horloge/2.pbm","r");
			  break;
			case 51:
			  un = fopen("/home/coco/projet2/Partage/Horloge/3.pbm","r");
			  break;
			case 52:
			  un = fopen("/home/coco/projet2/Partage/Horloge/4.pbm","r");
			  break;
			case 53:
			  un = fopen("/home/coco/projet2/Partage/Horloge/5.pbm","r");
			  break;
			case 54:
			  un = fopen("/home/coco/projet2/Partage/Horloge/6.pbm","r");
			  break;
			case 55:
			  un = fopen("/home/coco/projet2/Partage/Horloge/7.pbm","r");
			  break;
			case 56:
			  un = fopen("/home/coco/projet2/Partage/Horloge/8.pbm","r");
			  break;
			case 57:
			  un = fopen("/home/coco/projet2/Partage/Horloge/9.pbm","r");
			  break;
			default:
			  printf("Zbeub ?");
			  break;
		}
	
		a = fgetc(mem);

		switch (a)
		{
			case 48:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/0.pbm","r");
			  break;
			case 49:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/1.pbm","r");
			  break;
			case 50:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/2.pbm","r");
			  break;
			case 51:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/3.pbm","r");
			  break;
			case 52:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/4.pbm","r");
			  break;
			case 53:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/5.pbm","r");
			  break;
			case 54:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/6.pbm","r");
			  break;
			case 55:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/7.pbm","r");
			  break;
			case 56:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/8.pbm","r");
			  break;
			case 57:
			  deux = fopen("/home/coco/projet2/Partage/Horloge/9.pbm","r");
			  break;
			default:
			  printf("Zbeub ?");
			  break;
		}
	
		a = fgetc(mem);

		switch (a)
		{
			case 48:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/0.pbm","r");
			  break;
			case 49:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/1.pbm","r");
			  break;
			case 50:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/2.pbm","r");
			  break;
			case 51:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/3.pbm","r");
			  break;
			case 52:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/4.pbm","r");
			  break;
			case 53:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/5.pbm","r");
			  break;
			case 54:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/6.pbm","r");
			  break;
			case 55:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/7.pbm","r");
			  break;
			case 56:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/8.pbm","r");
			  break;
			case 57:
			  trois = fopen("/home/coco/projet2/Partage/Horloge/9.pbm","r");
			  break;
			default:
			  printf("Zbeub ?");
			  break;
		}
	
		a = fgetc(mem);

		switch (a)
		{
			case 48:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/0.pbm","r");
			  break;
			case 49:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/1.pbm","r");
			  break;
			case 50:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/2.pbm","r");
			  break;
			case 51:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/3.pbm","r");
			  break;
			case 52:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/4.pbm","r");
			  break;
			case 53:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/5.pbm","r");
			  break;
			case 54:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/6.pbm","r");
			  break;
			case 55:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/7.pbm","r");
			  break;
			case 56:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/8.pbm","r");
			  break;
			case 57:
			  quatre = fopen("/home/coco/projet2/Partage/Horloge/9.pbm","r");
			  break;
			default:
			  printf("Zbeub ?");
			  break;
		}	
	
		a = fgetc(mem);

		switch (a)
		{
			case 48:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/0.pbm","r");
			  break;
			case 49:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/1.pbm","r");
			  break;
			case 50:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/2.pbm","r");
			  break;
			case 51:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/3.pbm","r");
			  break;
			case 52:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/4.pbm","r");
			  break;
			case 53:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/5.pbm","r");
			  break;
			case 54:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/6.pbm","r");
			  break;
			case 55:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/7.pbm","r");
			  break;
			case 56:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/8.pbm","r");
			  break;
			case 57:
			  cinq = fopen("/home/coco/projet2/Partage/Horloge/9.pbm","r");
			  break;
			default:
			  printf("Zbeub ?");
			  break;
		}
		
		a = fgetc(mem);

		switch (a)
		{
			case 48:
			  six = fopen("/home/coco/projet2/Partage/Horloge/0.pbm","r");
			  break;
			case 49:
			  six = fopen("/home/coco/projet2/Partage/Horloge/1.pbm","r");
			  break;
			case 50:
			  six = fopen("/home/coco/projet2/Partage/Horloge/2.pbm","r");
			  break;
			case 51:
			  six = fopen("/home/coco/projet2/Partage/Horloge/3.pbm","r");
			  break;
			case 52:
			  six = fopen("/home/coco/projet2/Partage/Horloge/4.pbm","r");
			  break;
			case 53:
			  six = fopen("/home/coco/projet2/Partage/Horloge/5.pbm","r");
			  break;
			case 54:
			  six = fopen("/home/coco/projet2/Partage/Horloge/6.pbm","r");
			  break;
			case 55:
			  six = fopen("/home/coco/projet2/Partage/Horloge/7.pbm","r");
			  break;
			case 56:
			  six = fopen("/home/coco/projet2/Partage/Horloge/8.pbm","r");
			  break;
			case 57:
			  six = fopen("/home/coco/projet2/Partage/Horloge/9.pbm","r");
			  break;
			default:
			  printf("Zbeub ?");
			  break;
		}
		//fin iuverture des fichier pbm pour le chargement des nombres 
		fclose(mem);
	
		i = 0;
	
		deuxpt = fopen("/home/coco/projet2/Partage/Horloge/:.pbm","r");
		deuxpt2 = fopen("/home/coco/projet2/Partage/Horloge/:.pbm","r");
	
//place tous les curseurs pour que chaque fichier soit pres a être lu 

		fseek(deuxpt2, 4, SEEK_SET);	// premier ":"
		fgets(nom, 255, deuxpt2);
		fscanf(deuxpt2, "%d %d", &tabx, &taby);
		fgetc(deuxpt2);
		fgetc(deuxpt2);	
	
		fseek(deuxpt, 4, SEEK_SET);	// deuxieme ":"
		fgets(nom, 255, deuxpt);
		fscanf(deuxpt, "%d %d", &tabx, &taby);
		fgetc(deuxpt);
		fgetc(deuxpt);	
	
		fseek(un, 4, SEEK_SET);		// premier chiffre
		fgets(nom, 255, un);
		fscanf(un, "%d %d", &tabx, &taby);
		fgetc(un);
		fgetc(un);	

		fseek(deux, 4, SEEK_SET);
		fgets(nom, 255, deux);
		fscanf(deux, "%d %d", &tabx, &taby); 
		fgetc(deux);
		fgetc(deux);

		fseek(trois, 4, SEEK_SET);
		fgets(nom, 255, trois);
		fscanf(trois, "%d %d", &tabx, &taby); 
		fgetc(trois);
		fgetc(trois);

		fseek(quatre, 4, SEEK_SET);
		fgets(nom, 255, quatre);
		fscanf(quatre, "%d %d", &tabx, &taby); 
		fgetc(quatre);
		fgetc(quatre);

		fseek(cinq, 4, SEEK_SET);
		fgets(nom, 255, cinq);
		fscanf(cinq, "%d %d", &tabx, &taby); 
		fgetc(cinq);
		fgetc(cinq);

		fseek(six, 4, SEEK_SET);
		fgets(nom, 255, six);
		fscanf(six, "%d %d", &tabx, &taby); 
		fgetc(six);
		fgetc(six);

		// Lit chaque pmb ligne par ligne 

		while (i < 5)
		{
	
			for (truc = 0 ; truc < centrex ; truc++)
			printf(" ");
			a = 0;

				while (a != 10)
				{
					a = fgetc(un);
					 
					if (a == 48)			//Affichage 1
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}

				a = 0;

				while (a != 10)
				{
					a = fgetc(deux);

					if (a == 48)			//Affichage 2
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}

				a = 0;

				while (a != 10)
				{
					a = fgetc(deuxpt);

					if (a == 48)			//Affichage ":"
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}

				a = 0;

				while (a != 10)
				{
					a = fgetc(trois);

					if (a == 48)			//Affichage 3
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}
				a = 0;

				while (a != 10)
				{
					a = fgetc(quatre);

					if (a == 48)			//Affichage 4
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}

				a = 0;

				while (a != 10)
				{
					a = fgetc(deuxpt2);

					if (a == 48)			//Affichage ":"
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}

				a = 0;

				while (a != 10)
				{
					a = fgetc(cinq);

					if (a == 48)			//Affichage 5
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}
	
				a = 0;

				while (a != 10)
				{
					a = fgetc(six);

					if (a == 48)			//Affichage 6
						printf(" ");
					else if (a == 49)
					{
						printf("%c", 219);
					}
				}


				i++;
				printf("\n");
		}

		for (truc = 0 ; truc < centrey ; truc++) //centre chaque 
			printf("\n");
		fclose(un);
		fclose(deux);
		fclose(trois);
		fclose(quatre);				//
		fclose(cinq);
		fclose(six);
		fclose(deuxpt);
		fclose(deuxpt2);
		printf("Rafraichissement toutes les %d sec ", tmp);
		for (truc = 0 ; truc < tmp ; truc++){		
		printf("-");
		fflush(stdout);
		sleep(1);
		
		}
		system("clear");
	}	

	return 0;
}
